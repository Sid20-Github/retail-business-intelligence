# Dataset Submission — AdventureWorks2022

**Module:** B9DA111 Data Storage Solutions for Data Analytics  
**Group:** Austin Joy (20089607), Siddhi Raju Choughule (20096234), Pankhuri Mishra (20083872)

---

## Dataset used

| Item | Detail |
|------|--------|
| **Name** | AdventureWorks2022 |
| **Type** | Microsoft SQL Server sample OLTP database |
| **Edition** | SQL Server 2022 |
| **Subject area** | Retail Internet Sales (`Sales` + `Production` schemas) |
| **Scope filter** | `OnlineOrderFlag = 1`, exclude cancelled orders (`Status ≠ 6`) |
| **Records in scope** | ~27,659 orders · ~60,398 order lines · $29.4M revenue (2011–2014) |

---

## Official dataset links (paste on Moodle)

Post this link in the Moodle **dataset URL** field:

**https://learn.microsoft.com/en-us/sql/samples/adventureworks-install-configure**

Backup / direct download links:

- https://github.com/Microsoft/sql-server-samples/releases
- https://github.com/Microsoft/sql-server-samples/releases/latest (AdventureWorks2022.bak)

---

## Dataset files included in this submission zip

| File / folder | Description |
|---------------|-------------|
| `AdventureWorks2022_InternetSales_CSV/` | Our extracted internet-sales subset (7 CSV files from AdventureWorks2022) |
| `export_for_neo4j.sql` | SQL script used to generate the CSV exports |
| `../SQL_DataWarehouse/` | Scripts that build **AW_Retail_DW** analytical dataset from AdventureWorks2022 |

### CSV files (retail internet sales scope)

| File | Rows | Purpose |
|------|------|---------|
| customers.csv | ~19,820 | Customer nodes for Neo4j / graph analytics |
| products.csv | ~504 | Product catalogue with category |
| categories.csv | 4 | Product category lookup |
| territories.csv | 10 | Sales territory dimension |
| employees.csv | 17 | Salesperson dimension |
| orders.csv | ~27,659 | Internet order headers |
| order_lines.csv | ~60,398 | Order line detail (fact grain) |

**Filter applied:** `OnlineOrderFlag = 1`, cancelled orders excluded — same scope as AW_Retail_DW.

---

## Why this dataset

- Industry-standard, well-documented, and **permitted by the assignment brief**
- Realistic relational complexity (orders, products, customers, territories)
- Includes `ModifiedDate` columns for incremental ETL demonstration
- Avoids external Kaggle datasets per lecturer guidance

---

## Our analytical copy

| Database | Purpose |
|----------|---------|
| AdventureWorks2022 | Operational source (OLTP) |
| AW_Retail_DW | Dimensional data warehouse (star schema) |

ETL scripts: `sql/05_ETL_LOAD_FROM_ADVENTUREWORKS.sql`  
Neo4j export: `neo4j/export_for_neo4j.sql`

---

## Moodle submission checklist

- [ ] Upload group zip (`B9DA111_FINAL_MOODLE_SUBMISSION.zip`)
- [ ] Upload **star_schema.svg** (included in zip under `Schema/`)
- [ ] Paste dataset link above in Moodle dataset URL field
- [ ] One submission per group
