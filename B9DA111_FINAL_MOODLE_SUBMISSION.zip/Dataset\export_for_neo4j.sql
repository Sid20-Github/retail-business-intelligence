-- ============================================================================
-- export_for_neo4j.sql
-- Export AdventureWorks2022 subsets to CSV for Neo4j import
-- Run in SSMS with Results to File or bcp
-- Output folder: neo4j/import/
-- ============================================================================

USE AdventureWorks2022;
GO

-- Export instructions (run each query and save as CSV with headers):

-- 1. customers.csv
SELECT
    c.CustomerID                          AS customerId,
    CASE WHEN c.PersonID IS NOT NULL THEN 'Individual' ELSE 'Store' END AS type,
    COALESCE(CONCAT(p.FirstName, ' ', p.LastName), s.Name) AS name,
    st.CountryRegionCode                  AS country,
    c.TerritoryID                         AS territoryId
FROM Sales.Customer c
LEFT JOIN Person.Person p ON c.PersonID = p.BusinessEntityID
LEFT JOIN Sales.Store s ON c.StoreID = s.BusinessEntityID
LEFT JOIN Sales.SalesTerritory st ON c.TerritoryID = st.TerritoryID;

-- 2. products.csv
SELECT
    p.ProductID                           AS productId,
    p.Name                                AS name,
    pc.Name                               AS category,
    psc.Name                              AS subcategory,
    CAST(p.ListPrice AS DECIMAL(10,2))    AS listPrice
FROM Production.Product p
LEFT JOIN Production.ProductSubcategory psc ON p.ProductSubcategoryID = psc.ProductSubcategoryID
LEFT JOIN Production.ProductCategory pc ON psc.ProductCategoryID = pc.ProductCategoryID;

-- 3. categories.csv
SELECT ProductCategoryID AS categoryId, Name AS name
FROM Production.ProductCategory;

-- 4. territories.csv
SELECT TerritoryID AS territoryId, Name AS name, [Group] AS regionGroup, CountryRegionCode AS country
FROM Sales.SalesTerritory;

-- 5. employees.csv
SELECT
    sp.BusinessEntityID                   AS employeeId,
    CONCAT(p.FirstName, ' ', p.LastName)  AS name,
    CAST(sp.SalesQuota AS DECIMAL(12,2))  AS salesQuota
FROM Sales.SalesPerson sp
INNER JOIN Person.Person p ON sp.BusinessEntityID = p.BusinessEntityID;

-- 6. orders.csv
SELECT
    h.SalesOrderNumber                    AS orderNumber,
    CONVERT(VARCHAR(10), h.OrderDate, 120) AS orderDate,
    CAST(h.TotalDue AS DECIMAL(12,2))     AS totalDue,
    h.CustomerID                          AS customerId,
    h.TerritoryID                         AS territoryId,
    h.SalesPersonID                       AS employeeId
FROM Sales.SalesOrderHeader h
WHERE h.OnlineOrderFlag = 1 AND h.Status NOT IN (4, 6);

-- 7. order_lines.csv
SELECT
    h.SalesOrderNumber                    AS orderNumber,
    d.ProductID                           AS productId,
    d.OrderQty                            AS quantity,
    CAST(d.UnitPrice AS DECIMAL(10,2))    AS unitPrice,
    CAST(d.LineTotal AS DECIMAL(12,2))    AS lineTotal
FROM Sales.SalesOrderHeader h
INNER JOIN Sales.SalesOrderDetail d ON h.SalesOrderID = d.SalesOrderID
WHERE h.OnlineOrderFlag = 1 AND h.Status NOT IN (4, 6);
