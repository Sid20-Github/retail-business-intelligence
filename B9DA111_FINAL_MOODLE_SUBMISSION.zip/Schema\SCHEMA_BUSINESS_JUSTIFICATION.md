# Star Schema — Business Justification for Dimension Variables

**Project:** AW_Retail_DW (Retail Internet Sales)  
**Source dataset:** Microsoft AdventureWorks2022  
**Diagram file:** `star_schema.svg` (submit this .svg to Moodle)

This document satisfies the requirement that **each dimension has a minimum of five variables**, and **each variable has a clear business justification**.

---

## DimDate (8+ variables shown — calendar dimension)

| Variable | Business justification |
|----------|-------------------------|
| DateKey | Integer surrogate key (YYYYMMDD) for fast joins and partitioning in the fact table |
| FullDate | Actual calendar date used in daily/weekly sales trend reports |
| MonthName / MonthNumber | Supports monthly seasonality analysis (summer peak May–Aug) for VP Sales |
| Quarter / QuarterName | Enables quarterly executive summaries and board-level reporting |
| Year | Year-on-year growth comparisons required by CFO (BQ1 monthly sales) |
| IsWeekend | Identifies weekend vs weekday purchasing behaviour for marketing campaigns |
| FiscalYear / FiscalQuarter | Aligns sales reporting with Adventure Works financial calendar (July FY start) |

---

## DimProduct (9+ variables — SCD Type 2)

| Variable | Business justification |
|----------|-------------------------|
| ProductKey | Warehouse surrogate key; isolates analytics from OLTP product changes |
| ProductID / ProductNumber | Business keys for traceability back to AdventureWorks2022 Production.Product |
| ProductName | Product-level performance ranking in SSRS Product Performance report (BQ2) |
| CategoryName / SubcategoryName | Category mix analysis (bikes vs accessories vs clothing) for product managers |
| StandardCost / ListPrice | Margin analysis — accessories often have higher margin % than bikes |
| Color / Size | Attribute segmentation for merchandising and assortment planning |
| StartDate / EndDate / IsCurrent | SCD Type 2 preserves historical prices when ListPrice changes over time |

---

## DimCustomer (8+ variables — SCD Type 2)

| Variable | Business justification |
|----------|-------------------------|
| CustomerKey | Surrogate key for analytics; supports slowly changing customer attributes |
| CustomerID | Links to source Sales.Customer for audit and reconciliation |
| CustomerType | Segments Individual vs Store customers — individuals drive more internet revenue |
| CustomerName | Top-50 customer analysis and quartile reporting (BQ3 / SSRS Customer Analysis) |
| TerritoryName / CountryRegion | Geographic context for customer value and regional marketing |
| EmailPromotion | Marketing opt-in flag for campaign targeting and consent-aware analytics |
| StartDate / EndDate / IsCurrent | SCD Type 2 tracks address/territory changes without losing historical accuracy |

---

## DimTerritory (7 variables — SCD Type 1)

| Variable | Business justification |
|----------|-------------------------|
| TerritoryKey | Surrogate key for joining sales to sales regions |
| TerritoryID | Business key from Sales.SalesTerritory in AdventureWorks2022 |
| TerritoryName | Territory ranking report — Australia #1, US regions lead volume (BQ4) |
| CountryRegionCode | Country-level aggregation for international sales comparison |
| RegionGroup | Groups territories into North America, Europe, Pacific for regional managers |
| SalesYTD / SalesLastYear | Benchmarks territory performance against source quotas and prior year |

---

## DimEmployee (6 variables — includes Unknown member)

| Variable | Business justification |
|----------|-------------------------|
| EmployeeKey | Surrogate key; key 0 = Unknown for internet orders without assigned salesperson |
| EmployeeID | Business key from HumanResources.Employee / Sales.SalesPerson |
| EmployeeName | Attributes revenue to named sales representatives where applicable |
| Title | Role-based views (e.g. Sales Representative vs Sales Manager) |
| TerritoryName | Aligns salesperson to their assigned sales territory |
| SalesQuota / CommissionPct | Supports quota attainment and incentive compensation analysis |

---

## DimPromotion (5 variables — includes No Promotion member)

| Variable | Business justification |
|----------|-------------------------|
| PromotionKey | Surrogate key; key 0 = No Promotion for non-discounted order lines |
| PromotionID | Business key from Sales.SpecialOffer in AdventureWorks2022 |
| PromotionName | Identifies which campaigns drove incremental sales |
| DiscountPct | Quantifies discount depth and impact on gross margin |
| Type / Category | Classifies promotions (e.g. seasonal vs clearance) for marketing ROI |

---

## FactInternetSales (measures at order-line grain)

| Variable | Business justification |
|----------|-------------------------|
| OrderQty | Units sold — inventory and volume KPIs on Tableau dashboard |
| UnitPrice | Selling price per unit for price/mix analysis |
| DiscountAmount | Total line discount — promotion effectiveness |
| LineTotal | Revenue measure reconciled to OLTP (zero variance validation) |
| StandardCost | Cost at time of sale for margin reporting |
| GrossProfit | LineTotal − (StandardCost × OrderQty) — CFO margin KPI |

---

## Compliance checklist (lecturer requirements)

| Requirement | Status |
|-------------|--------|
| Minimum 4 dimensions | ✅ 6 dimensions (Date, Product, Customer, Territory, Employee, Promotion) |
| Each dimension ≥ 5 variables | ✅ All dimensions meet or exceed 5 attributes |
| Business justification per variable | ✅ Documented above |
| Schema submitted as .svg | ✅ `star_schema.svg` |
